# Happy Textures :3

A mod that will fix small texture annoyances

Current features include:

- Having a separate image for the title on the Menu Layer by adding GJ_title.png in your resources
- Replacing bigFont does not affect levels anymore

Feature requests welcome, DM me @Alphalaneous on Discord