Adds gradients to a bunch of pages in the game like:

- Player Profiles
- Level Descriptions
- And more to come!

If you want more areas of the game added, ping me on the [Geode Discord Server](https://discord.gg/9e43WMKzhp) (I'm **@TheSillyDoggo**)

This mod has customizable options, check them out as it can improve your experience a lot :D
