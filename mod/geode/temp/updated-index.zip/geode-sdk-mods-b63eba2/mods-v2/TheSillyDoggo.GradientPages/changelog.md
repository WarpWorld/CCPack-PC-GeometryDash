# 2.2.0

- Fixed outlines on music / sfx library
- Fixed Grandpa Demon Incompatibility

# v2.1.0

 * Added **ItemInfoPopup**, **ShardsPage**, **CommunityCreditsPage**, **DemonFilterSelectLayer**, **MoreSearchLayer** (Search filter page), **Go to page popup** and **ChallengesPage** (Quests)
 * **Remember that if you don't like these you CAN disable pages in the mod options**
 * Removed **Herobrine**

# v2.0.0

 * Added Android Support :D
 * Added a few more profile related layers (**FRequestPage**, **GJAccountSettingsLayer** etc)
 * Updated **about.md**
 * Added **changelog.md**
 * Added **Herobrine**
 * Added 2.204 support

# v1.0.0

 * Initial release