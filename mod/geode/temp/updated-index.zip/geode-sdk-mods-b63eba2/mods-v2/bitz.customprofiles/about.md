# CustomProfiles
Customize your profile with a new and interesting interface!


## **Android and Mac Support!**
- Now the customizations are available on android and mac!

## **Features**

- Customization for Corners
- Customization for Colors
- Disable info button
- Profile colors animation!

## **How to customize it**

**- Windows**
To customize your profile you have to go to the gray options button found in your profile, there you will have all the options to add or remove from the profile.

**- Android and Mac**
The customizations are in the mod settings! They work only for android and mac
#
## **And that's it! I hope you have fun using it <3**
