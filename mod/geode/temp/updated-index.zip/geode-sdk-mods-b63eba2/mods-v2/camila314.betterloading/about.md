# BetterLoading

BetterLoading is a mod that decreases level loading times by up to 4x. This is currently in beta, it's not guaranteed to be stable.