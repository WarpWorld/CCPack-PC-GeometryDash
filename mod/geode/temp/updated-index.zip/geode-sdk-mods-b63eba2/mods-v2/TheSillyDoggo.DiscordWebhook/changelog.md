# v1.0.0

 - Initial release

 # v1.0.1

 - Fix periods and capital letters not being allowed in text boxes. sorry :(