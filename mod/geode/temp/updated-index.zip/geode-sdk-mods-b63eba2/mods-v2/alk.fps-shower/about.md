# FPS Shower

It's just an standalone fps overlay mod.

## Credits

Developed by Alk1m123 (alk) with love (not tears this time). Please support me!

 * [Patreon](https://www.patreon.com/alk1m123)

 * [Twitter](https://twitter.com/alk1m123)

 * [Reddit](https://www.reddit.com/user/alk1m123)

 * [Github](https://github.com/altalk23/)
