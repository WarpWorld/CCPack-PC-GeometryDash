# v1.0.3

 + Moved the button to the game options menu 

# v1.0.2

 + Fixed some bugs with mods

# v1.0.1

 + Fixed a weird bug with the collisions

# v1.0.0

 + Initial release