# Gamemode Changer

Basically it lets you change between normal and platformer mode in-game.