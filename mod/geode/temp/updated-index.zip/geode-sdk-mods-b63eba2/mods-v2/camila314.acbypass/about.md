# Anticheat Bypass

Bypass the anti-cheat system in Geometry Dash. Most likely used as a dependency.