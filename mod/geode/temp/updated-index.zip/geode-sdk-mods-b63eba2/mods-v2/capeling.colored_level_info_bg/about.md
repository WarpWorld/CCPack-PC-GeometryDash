# Coloured Level Page

Colours the level page based off of the level difficulty