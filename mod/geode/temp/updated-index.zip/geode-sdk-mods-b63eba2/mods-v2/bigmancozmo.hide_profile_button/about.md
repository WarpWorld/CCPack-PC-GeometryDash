# Hide Profile Button

A simple mod used to **hide** the profile button from the **main menu**.
Can be toggled from the **mod's settings**.
The option to hide your name *only* is also in the **mod settings**.

Logo by [RayDeeUx](https://github.com/RayDeeUx)
