# DeathLink

With DeathLink, you can link your deaths with another player (that also has the mod). That means if they die, you die too! You can use this to try and beat levels simultaneously, make a platforming challenge harder, or just to mess around. Enjoy and have fun!

To link, go to the ![link](frame:gj_linkBtn_001.png&scale:0.5) button on the main menu, click link, and then enter a username for whom you want to die with. 