# FPS Bypass (MacOS)

An FPS bypass that replaces the internal timer. 

When the vsync is enabled, the update will be tied to the monitor refresh rate. When disabled, it will use a separate timer instead.

Therefore, the fps setting is useless when vsync is enabled.

## Credits

Developed by Alk1m123 (alk) with love (not tears this time). Please support me!

 * [Patreon](https://www.patreon.com/alk1m123)
 * [Twitter](https://twitter.com/alk1m123)
 * [Reddit](https://www.reddit.com/user/alk1m123)
 * [Github](https://github.com/altalk23/)
