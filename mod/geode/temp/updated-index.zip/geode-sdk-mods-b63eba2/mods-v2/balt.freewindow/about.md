# FreeWindow

Lets you freely resize the window. Useful for ultrawide displays.