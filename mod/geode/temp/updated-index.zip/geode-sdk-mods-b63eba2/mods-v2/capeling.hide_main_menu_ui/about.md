# Hide Main Menu UI

Adds a button to the main menu that hides the UI!