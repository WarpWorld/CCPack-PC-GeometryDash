# NoMoreGames

This mod deletes the more games button!
