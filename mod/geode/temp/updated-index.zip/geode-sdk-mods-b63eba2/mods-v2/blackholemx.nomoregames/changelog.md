# v1.1.0

* Macos Support

# v1.0.0

* Initial release
