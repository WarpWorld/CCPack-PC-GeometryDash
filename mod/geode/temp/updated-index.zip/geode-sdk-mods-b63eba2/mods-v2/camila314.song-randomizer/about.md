# Song Randomizer

Adds a button in the editor to find a random song on newgrounds.