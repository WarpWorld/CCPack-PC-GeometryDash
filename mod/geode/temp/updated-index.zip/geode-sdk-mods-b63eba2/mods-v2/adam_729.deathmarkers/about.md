# Death Markers

Super Mario Maker death markers in gd.
Submit bug reports or new feature requests on the github repository.
Check the github repo for some alternate icon texture packs.

### check the mod settings (i added a lot of new useful settings in this update)