# GodlikeFaces

Geode Mod that adds back the overexaggerated faces concept for Mythic by Robtop. Art by @RobtopGemes on twitter!