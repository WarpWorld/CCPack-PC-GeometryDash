# Icon Profile

Replaces the Main Menu Profile Sprite with your icon, now for 2.2!