# Icon Profile Changelog
## v1.1.4
- Robot & Spider are now Animated
## v1.1.3
- Help Update Geode for Users on beta.12
## v1.1.2
- Fix Robot and Spider not having any colors
## v1.1.1
- Bump Android Version (2.205)
## v1.1.0
- Added 2.2 support (fixed compiling) for Android
- Added Swing icon support
- Added Jetpack icon support
## v1.0.0
- Added 2.2 support
