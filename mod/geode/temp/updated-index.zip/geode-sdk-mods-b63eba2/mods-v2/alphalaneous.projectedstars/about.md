# Projected Stars

Shows how many stars you will get if you beat a level with some extra flair!
