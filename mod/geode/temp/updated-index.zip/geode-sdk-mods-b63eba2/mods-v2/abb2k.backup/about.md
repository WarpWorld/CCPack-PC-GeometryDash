# The Backup Mod

this mod allows you to easily create backups of your save file
and also automatically create backups!

now you will never lose your save again! :D

-----------

to use the auto backups you need to go to the settings, enable it and specify how many backups you allow to exist at a time.

note that importing backups isnt supported on android yet.