# v1.0.5

 * improved backup exporting and importing stuff (old exported backups will not works anymore) and removed exporting and importing backups from android, this might be supported in the future but idk

# v1.0.4

 * fixed a small issue with android backup loading not working

# v1.0.3

 * fixed my code, UI breaking on different resolutions and auto backups! also added android support!! :D (Importing backups isnt working on android yet)

# v1.0.2

 * added the option to export and import backups and fixed some code

# v1.0.1

 * changed the geode version compatable with the mod

# v1.0.0

 * Initial release