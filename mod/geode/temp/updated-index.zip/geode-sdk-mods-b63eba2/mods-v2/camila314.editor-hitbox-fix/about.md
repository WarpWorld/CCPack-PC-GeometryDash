# Editor Hitbox Fix

Fixes rotatable hitboxes in editor