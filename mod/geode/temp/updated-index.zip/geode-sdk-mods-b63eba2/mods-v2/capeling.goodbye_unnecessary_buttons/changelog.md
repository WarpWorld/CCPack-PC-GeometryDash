# Goodbye Unnecessary Buttons Changelog
## v1.1.0
- Swapped The Quests and Paths Buttons
- Swapped The Lists and Map Packs Buttons
## v1.0.3
- Bump Android Version (2.205)
## v1.0.2
- Fix Mod Name Typo
- Fix Incorrect About Description
## v1.0.1
- Fix Mod ID Typo
## v1.0.0
- Removes The Versus, Map and Event buttons from CreatorLayer!