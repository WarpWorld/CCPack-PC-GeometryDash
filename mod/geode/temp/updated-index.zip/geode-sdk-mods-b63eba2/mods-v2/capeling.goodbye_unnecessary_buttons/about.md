# Goodbye Unnecessary Buttons

Removes The Versus, Map and Event buttons from CreatorLayer!
