# EditorAPI

An API for modders to make working with the editor easier, as well as provide shared utilities for adding stuff to it.

Developed as a part of [BetterEdit](https://github.com/hjfod/BetterEdit), however it is not required to use EditorAPI.
