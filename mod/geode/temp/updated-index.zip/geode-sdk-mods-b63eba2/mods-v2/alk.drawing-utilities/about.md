# Drawing Utilities

Right now only includes drawing lines, but bezier curves and space filling are planned.

Also UI to be implemented.