# Icon Profile

Replaces the Main Menu Profile Sprite with your icon!

# Credits

- iAndyHD3
- camila314
- [Original Mod](https://github.com/iAndyHD3/small-gd-mods)
- Geode
