# Demons In Garage 2.2 Changelog
## v1.1.4
- Changed Demon Texture
- Added ID's to the Label & Sprite
## v1.1.3
- Fixed Some Positioning Errors
## v1.1.2
- Fixed Android32 Crash
## v1.1.1
- Bump Android Version (2.205)
## v1.1.0
- New Logo
- Fixed for Geode 2.0.0
- Android Compatibilty
## v1.0.0
- Adds your demon count into the garage, now for 2.2!