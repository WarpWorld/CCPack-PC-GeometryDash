# Demons In Garage 2.2

Adds your demon count in the Icon Kit.