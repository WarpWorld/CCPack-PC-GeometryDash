# Template Mod

This mod makes the main menu look a little bit better! It does have bugs tho... I will fix them in later updates.
