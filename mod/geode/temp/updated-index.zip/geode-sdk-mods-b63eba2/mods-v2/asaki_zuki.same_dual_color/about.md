# Same Dual Color
Make the colors of two players the same in level and editor.