# PlayerColorSelect

Adds back the P1 and P2 select for Copy Color