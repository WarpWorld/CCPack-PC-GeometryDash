# 1.1.4

- Added additional borders for npesta texture pack users
- Fixed RobTop levels with the level edit fix
- Added Force Object Visibility
- Added No Glow
- ~~Added Noclip Deaths and Noclip Accuracy~~ it's delayed because this shits annoying to fix
- Added Alerts to the text bypasses to let the user know that they can crash
- Added Instant Restart
- Added Transition Customizer
- Fixed Solid Wave Trail white being broken
- Temporarily removed thicker hitboxes due to lag :(

# 1.1.3

- Fixed Level Edit breaking level page, for anyone who used this before the update: Press the ? button in the levels tab while in the broken level. Do this fast as the button WILL BE REMOVED IN THE FUTURE
- Added Force Trail On and Force Trail Off
- Added No Camera Shake
- Added Force Platformer On Android
- Moved Confirm Practice and Confirm Restart From Universal to Level
- Added Menu Animations, From Left, From Right, From Top, From Bottom and Scale
- Added FPS Bypass (Beta)
- Added Noclip broken slope fix
- Added ~~Herobrine~~ Zulguroth

# 1.1.2

- Added Level Edit
- Removed boob dropdown (sad day)
- Fixed lag with Transparent BG

# 1.1.1

- Added hide endscreen
- Fixed button not being clickable on the pause menu
- Re enable text bypasses
- Fix incorrect menu speed during transition
- Re-added the text bypasses due to hopefully fixing the crashes
- Added Transparent BG & Transparent Lists
- Added Confirm Practice and Confirm Restart
- Fixed show hitboxes breaking (vanilla one)
- Added thicker hitboxes

# 1.1.0

- Added Icon Effects (RGB Icons)
- Added no Wave Trail
- Removed the text limit bypasses due to crashes, sorry :/
- Created an official [Discord Server](https://discord.gg/DfQSTEnQKK)

# 1.0.3

- Added back the button wheh in gameplay
- Fixed pause crash with speedhack

# 1.0.2

- Fixed crash when playing user levels
- Added character filter and character limit bypass
- ~~Fixed balls duplicating~~ nvm i broke it :(
- Pause menu is still broken, if you can't click any buttons press esc or the back button on your phone (the arrow)
- Added No Particles, No Shaders, Text Limit Bypass, Text Character Bypass and Speedhack Music

# 1.0.1

- Fixed force priority issues in newest geode build
- Fixed absolllutes credits button being bigger on medium and low graphics
- Added trash button next to speedhack input
- Fixed crashes on some phones when changing menus

# 1.0.0

- Initial Release