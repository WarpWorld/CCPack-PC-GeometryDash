# QOLMod

<co>Note:</c> This mod only has a mobile <cl>UI</c> currently, if you want a Mega Hack like menu, wait for the update to release

QOLMod is **THE** mod menu for android, it has a Mobile Optimised <cl>UI</c> with many features to improve your mobile <cg>Geometry Dash</c> experience such as a Speedhack, Copy hack, Icon Effects, Noclip Accuracy, Unlock item hack and more.

Join the [Discord Server (https://discord.gg/DfQSTEnQKK)](https://discord.gg/DfQSTEnQKK)