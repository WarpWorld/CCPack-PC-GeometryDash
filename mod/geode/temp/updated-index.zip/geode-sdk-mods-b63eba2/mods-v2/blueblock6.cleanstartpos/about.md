# Clean Startpos

Puts all the Startpos options on one page

![Example](blueblock6.cleanstartpos/example.png)