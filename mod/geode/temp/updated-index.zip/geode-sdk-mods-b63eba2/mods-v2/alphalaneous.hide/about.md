# hIDe

Hides level IDs on the Edit Level page unless shift is held to prevent level leaks.

Idea by: TerminumGD