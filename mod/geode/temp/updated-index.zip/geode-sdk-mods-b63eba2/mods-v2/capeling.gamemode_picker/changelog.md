# Gamemode Swapper Changelog
## v1.0.5
- Fixed download
## v1.0.4
- Added keybinding support
- Fixed bug with BetterPause (hopefully)
- Added Node IDS for all GamemodeLayer nodes
## v1.0.3
- Added ID to the gamemode editor button
- Bottom button now is added to a menu, preventing overlapping with the coins in menu mod
- Removed some leftover logs
- Added Node IDS as a depencency
- Added "gameplay" tag
## v1.0.2
- Fixed the platformer UI not appearing on Android
## v1.0.1
- Adds an option to move the button to top right
- Attempted touch prio fixes
## v1.0.0
- Adds a button in the Pause Menu that allows you to change your gamemode!
