# Gamemode Swapper

Adds a button in the Pause Menu that allows you to change your gamemode!