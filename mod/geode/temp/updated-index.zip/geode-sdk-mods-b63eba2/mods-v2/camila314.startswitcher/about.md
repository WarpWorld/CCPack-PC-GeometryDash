# StartPos Switcher

Use the right and left arrow keys to switch between start positions!