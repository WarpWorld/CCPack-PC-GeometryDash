# Demon List Team Icons

A simple mod to add an icon for Demon List team members.