# Integrated Loquibot

Go through the queue of Loquibot inside the game rather than clicking out of it.

Loquibot is a Twitch and YouTube chat bot that supports Geometry Dash Level Requesting, it can be found at https://loquibot.com/