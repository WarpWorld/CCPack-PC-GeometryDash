# Icon Randomizer

Adds a button in the Color Selection menu to randomize your icons!
