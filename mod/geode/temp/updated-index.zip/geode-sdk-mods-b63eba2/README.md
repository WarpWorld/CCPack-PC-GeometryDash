# Mods

This is the public **Mods Index** for Geode. The mods listed here will show up on the in-game list as part of the Geode API, and users can download & install mods that appear here through that list.

## Getting your mod here

To get your mod listed on the repository, [follow the publishing instructions from the docs.](https://docs.geode-sdk.org/mods/publishing)
